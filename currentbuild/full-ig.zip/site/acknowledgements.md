# Acknowledgements - v0.1.0

* [**Table of Contents**](toc.md)
* **Acknowledgements**

## Acknowledgements

No use of external IP

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.nordic.careplans.r4)](package.r4.tgz) and [R4B (hl7.fhir.nordic.careplans.r4b)](package.r4b.tgz) are available.

*There are no Global profiles defined*

### Dependencies



