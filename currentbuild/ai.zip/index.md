# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://nordic.hl7.org/fhir/ig/hl7.fhir.nordic.careplans/ImplementationGuide/hl7.fhir.nordic.careplans | *Version*:0.1.0 |
| Draft as of 2026-01-19 | *Computable Name*:CarePlanExamples |

### Introduction

